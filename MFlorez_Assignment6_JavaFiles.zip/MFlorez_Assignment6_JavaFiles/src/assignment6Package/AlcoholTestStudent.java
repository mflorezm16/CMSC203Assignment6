package assignment6Package;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AlcoholTestStudent {
	
//	private Alcohol alcohol1;
//    private Alcohol alcohol2;
//    private Alcohol alcoholWeekend;
//    private Alcohol alcoholNoWeekend;

	@Before
	public void setUp() throws Exception {
	 Alcohol alcohol1 = new Alcohol("Beer", Size.SMALL, false);  
     Alcohol alcohol2 = new Alcohol("Wine", Size.MEDIUM, false);
     Alcohol alcoholWeekend = new Alcohol("Vodka", Size.LARGE, true);
	 Alcohol alcoholNoWeekend = new Alcohol("Whiskey", Size.LARGE, false);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPriceCalcSmallNoWeekend() {
		Alcohol alcohol1 = new Alcohol("Beer", Size.SMALL, false);
        assertEquals(2.0, alcohol1.calcPrice(),0.01);
	}
	
	@Test
    public void testCalcPriceMediumNoWeekend() {
		Alcohol alcohol2 = new Alcohol("Beer", Size.SMALL, false);
        assertEquals(2.0, alcohol2.calcPrice(),0.01);
    }

    @Test
   public void testCalcPriceLargeWithWeekend() {
    	Alcohol alcoholWeekend = new Alcohol("Vodka", Size.LARGE, true);
        assertEquals(3.6, alcoholWeekend.calcPrice(), 0.01);
    }

    @Test
   public void testCalcPriceLargeNoWeekend() {
    	Alcohol alcoholNoWeekend = new Alcohol("Whiskey", Size.LARGE, false);
        assertEquals(3.0, alcoholNoWeekend.calcPrice(), 0.01);
    }

    @Test
   public void testToString() {
    	Alcohol alcohol1 = new Alcohol("Beer", Size.SMALL, false);
    	Alcohol alcoholWeekend = new Alcohol("Vodka", Size.LARGE, true);
        assertEquals("Beverage Name: Beer, Type: ALCOHOL, Size: SMALL, Offered on Weekend: No, Price: $2.0", alcohol1.toString());
        assertEquals("Beverage Name: Vodka, Type: ALCOHOL, Size: LARGE, Offered on Weekend: Yes, Price: $3.6", alcoholWeekend.toString());
    }

    @Test
    public void testEqualsTrue() {
        Alcohol alcohol3 = new Alcohol("Beer", Size.SMALL, false);
        assertTrue(alcohol3.equals(alcohol3));
    }

    @Test
    public void testEqualsFalseDifferentSize() {
    	Alcohol alcohol1 = new Alcohol("Beer", Size.SMALL, false);
    	Alcohol alcohol2 = new Alcohol("Wine", Size.MEDIUM, false);
        assertFalse(alcohol1.equals(alcohol2));
    }

//    @Test
//    public void testEqualsFalseDifferentWeekend() {
//        Alcohol alcohol4 = new Alcohol("Beer", Size.SMALL, true);  
//        assertFalse(alcohol4.equals(alcohol4));
//    }

    @Test
    public void testEqualsFalseNull() {
    	Alcohol alcohol1 = new Alcohol("Wine", Size.MEDIUM, false);
        assertFalse(alcohol1.equals(null));
    }

    @Test
    public void testEqualsFalseDifferentClass() {
    	Alcohol alcohol1 = new Alcohol("Wine", Size.MEDIUM, false);
        assertFalse(alcohol1.equals("Not Alcohol"));
    }

    @Test
    public void testSetWeekendTrue() {
    	Alcohol alcoholWeekend = new Alcohol("Vodka", Size.LARGE, true);;
        assertTrue(alcoholWeekend.getWeekend());
    }

    @Test
    public void testSetWeekendFalse() {
    	Alcohol alcoholWeekend = new Alcohol("Vodka", Size.LARGE, false);;
        assertFalse(alcoholWeekend.getWeekend());
    }

}
