package assignment6Package;

public class Alcohol extends Beverage{
	
	private boolean weekend;
	private final double weekendCost = 0.60;
	
	public Alcohol(String name, Size size, boolean weekend) {
		super(name, Type.ALCOHOL, size);
		this.weekend = weekend;
	}

	

	
	
	
	
	@Override
	public String toString() {
		return super.toString() + ", Offered on Weekend: " + (weekend ? "Yes" : "No")
				+ ", Price: $" + calcPrice();
	}
	
	@Override
	public double calcPrice() {
		double price = addSizePrice();
		if(weekend) {
			price += weekendCost;
		}
		return price;
	}
	
	@Override
	public boolean equals (Object obj) {
		if(this == obj) return true;
		if(obj == null || getClass() != obj.getClass()) return false;
		if(!super.equals(obj)) return false;
		Alcohol alcohol = (Alcohol) obj;
		return weekend == alcohol.weekend;
	}







	public boolean getWeekend() {
		return weekend;
	}

}
