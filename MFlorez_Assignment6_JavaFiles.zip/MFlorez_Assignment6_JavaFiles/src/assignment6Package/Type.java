package assignment6Package;

public enum Type {
	COFFEE,
	SMOOTHIE,
	ALCOHOL;
}
