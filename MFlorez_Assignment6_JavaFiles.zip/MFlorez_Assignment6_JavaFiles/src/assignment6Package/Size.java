package assignment6Package;

public enum Size {
	SMALL,
	MEDIUM,
	LARGE;
}
