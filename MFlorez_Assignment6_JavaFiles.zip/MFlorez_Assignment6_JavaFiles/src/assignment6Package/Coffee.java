package assignment6Package;

public class Coffee extends Beverage{
	
	public static final double EXTRA_SHOT_COST = 0.5;
	public static final double EXTRA_SYRUP_COST = 0.5;
	
	private boolean extraShot;
	private boolean extraSyrup;
	
	public Coffee(String name, Size size, boolean extraShot, boolean extraSyrup) {
		super(name, Type.COFFEE, size);
		this.extraShot = extraShot;
		this.extraSyrup = extraSyrup;
	}
	

	@Override
	public String toString() {
		return super.toString() + ", Extra Shot: " + (extraShot ? "Yes" : "No")
				+ ", Extra Syrup: " + (extraSyrup ? "Yes" : "No")
				+ ", Price: $" + calcPrice();
	}
	
	@Override
	public double calcPrice() {
		double price = addSizePrice();
		if(extraShot) {
			price += EXTRA_SHOT_COST;
		}
		if(extraSyrup) {
			price += EXTRA_SYRUP_COST;
		}
		return price;
	}
	
	@Override
	public boolean equals (Object obj) {
		if(this == obj) return true;
		if(obj == null || getClass() != obj.getClass()) return false;
		if(!super.equals(obj)) return false;
		Coffee coffee = (Coffee) obj;
		return extraShot == coffee.extraShot && extraSyrup == coffee.extraSyrup;
	}
	
	public boolean hasExtraShot() {
		return extraShot;
	}
	
	public void setExtraShot(boolean extraShot) {
		this.extraShot = extraShot;
	}
	
	public boolean hasExtraSyrup() {
		return extraSyrup;
	}
	
	public void setExtraSyrup(boolean extraSyrup) {
		this.extraSyrup = extraSyrup;
	}

}
