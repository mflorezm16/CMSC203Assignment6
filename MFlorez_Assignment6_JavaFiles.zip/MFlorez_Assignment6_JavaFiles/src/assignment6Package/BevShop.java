package assignment6Package;

import java.util.ArrayList;
import java.util.List;

public class BevShop implements BevShopInterface {
	
//	private static final int MAX_ALCOHOL_ORDERS = 3;
//	private static final int MAX_NUM_OF_FRUITS = 5;
//	private static final int MIN_AGE_FOR_ALCOHOL = 21;
	private Order currentOrder;
	private int alcoholOrderCount;
	private List<Order> orders;
	private double totalSales;
	
	public BevShop() {
		this.alcoholOrderCount = 0;
		this.orders = new ArrayList<>();
		this.totalSales = 0.0;
		this.currentOrder = new Order();
	}
	
	public void addOrder(Order order) {
		int alcoholCountInOrder = 0;
		for(Beverage beverage : order.getBeverages()) {
			if(beverage.getType() == Type.ALCOHOL) {
				alcoholCountInOrder++;
			}
		}
		if(alcoholCountInOrder > MAX_ORDER_FOR_ALCOHOL) {
			System.out.println("Cannot add more than 3 alcoholic drinks");
		} else {
		
		if(alcoholCountInOrder > 0) {
			for(Beverage beverage : order.getBeverages()) {
				if(beverage.getType() == Type.ALCOHOL) {
					processAlcoholOrder(order);
				}
			}
		}
			orders.add(order);
			calculateTotalSales(order);
		}
	}
	
	
	public void processAlcoholOrder(Order order) {
		if(canOrderAlcohol(order.getCustomer())) {
			System.out.println("Processing alcohol order for " + order.getCustomer().getName());
			alcoholOrderCount += order.getBeverages().stream()
					.filter(beverage -> beverage.getType() == Type.ALCOHOL)
					.count();
		} else {
			System.out.println("Customer is underage, cannot order alcohol.");
		}
	}
	
	public boolean canOrderAlcohol(Customer customer) {
		return customer.getAge() >= 21;
	}
	
	private void calculateTotalSales(Order order) {
		double orderTotal = 0.0;
		for(Beverage beverage : order.getBeverages()) {
			orderTotal += beverage.calcPrice();
		}
		totalSales += orderTotal;
	}
	
	
	public double getTotalMonthlySale() {
		for(Order order : orders) {
			calculateTotalSales(order);
		}
		return totalSales;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Total Monthly Sales: $").append(totalSales).append("\nOrders:\n");
		
		for(Order order : orders) {
			sb.append(order.toString()).append("\n");
		}
		return sb.toString();
	}
	
	public int getAlcoholOrderCount() {
		return alcoholOrderCount;
	}
	
	public List<Order> getOrders(){
		return orders;
	}
	
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	@Override
	public boolean isValidTime(int time) {
		if(time >= MIN_TIME && time <= MAX_TIME) {
			return true;
		}
		return false;
	}

	@Override
	public int getMaxNumOfFruits() {
		return MAX_FRUIT;
	}

	@Override
	public int getMinAgeForAlcohol() {
		return MIN_AGE_FOR_ALCOHOL;
	}

	@Override
	public boolean isMaxFruit(int numOfFruits) {
		if(numOfFruits >= MAX_FRUIT) {
			return true;
		}
		return false;
	}

	@Override
	public int getMaxOrderForAlcohol() {
		return MAX_ORDER_FOR_ALCOHOL;
	}

	@Override
	public boolean isEligibleForMore() {
		int alcoholCount = 0;
		
		alcoholCount = currentOrder.alcoholCountInOrder();
		
		if(alcoholCount < MAX_ORDER_FOR_ALCOHOL) {
			return true;
		}
		return false;
	}

	@Override
	public int getNumOfAlcoholDrink() {
		
		return currentOrder.alcoholCountInOrder();
	}

	@Override
	public boolean isValidAge(int age) {
		if(age >= MIN_AGE_FOR_ALCOHOL) {
			return true;
		}
		return false;
	}

	@Override
	public void startNewOrder(int time, Day day, String customerName, int customerAge) {
		Customer customer = new Customer(customerName, customerAge);
		currentOrder = new Order(time, day, customer);
		orders.add(currentOrder);
	}

	@Override
	public void processCoffeeOrder(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		Coffee coffee = new Coffee(bevName, size, extraShot, extraSyrup);
		currentOrder.addNewBeverage(coffee); 
	}

	@Override
	public void processAlcoholOrder(String bevName, Size size) {
		Alcohol alcohol = new Alcohol(bevName, size, false); // need to double check the boolean
		if(currentOrder.alcoholCountInOrder() < 3) {
			currentOrder.addNewBeverage(alcohol); 		
		}
	}

	@Override
	public void processSmoothieOrder(String bevName, Size size, int numOfFruits, boolean addProtein) {
		Smoothie smoothie = new Smoothie(bevName, size, numOfFruits, addProtein);
		currentOrder.addNewBeverage(smoothie); 		
	}

	@Override
	public int findOrder(int orderNo) {
		for(int i = 0; i < orders.size(); i++) {
			if(orders.get(i).getOrderNumber() == orderNo) {
				return i;
			}
		}
		return -1;
	}

	@Override
	public double totalOrderPrice(int orderNo) {
		for(int i = 0; i < orders.size(); i++) {
			if(orders.get(i).getOrderNumber() == orderNo) {
				
				return orders.get(i).calcOrderTotal();
			}
		}
		return -1;
	}

	@Override
	public double totalMonthlySale() {
		double totalMonthlySales = 0;
		for(int i = 0; i < orders.size(); i++) {
			totalMonthlySales += orders.get(i).calcOrderTotal();
		}
		return totalMonthlySales;
	}

	@Override
	public int totalNumOfMonthlyOrders() {
		return orders.size();
	}

	@Override
	public Order getCurrentOrder() {
		return currentOrder;
	}

	@Override
	public Order getOrderAtIndex(int index) {
		return orders.get(index);
	}

	@Override
	public void sortOrders() {
        int n = orders.size();
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (orders.get(j).getOrderTime() < orders.get(minIndex).getOrderTime()) {
                    minIndex = j;
                }
            }
            if(minIndex != i) {
            	Order temp = orders.get(minIndex);
            	orders.set(minIndex,orders.get(i));
            	orders.set(i, temp);
            }
        }
	}
	
	public void clearOrders() {
		orders.clear();
	}

}
