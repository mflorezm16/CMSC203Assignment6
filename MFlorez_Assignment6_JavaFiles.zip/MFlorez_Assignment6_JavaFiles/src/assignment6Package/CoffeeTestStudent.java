package assignment6Package;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//import utility.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;


public class CoffeeTestStudent {
	
//	 private Coffee smallCoffee;
//	 private Coffee mediumCoffeeWithExtraShot;
//	 private Coffee largeCoffeeWithExtraSyrup;
//	 private Coffee mediumCoffeeWithExtraShotAndSyrup;

	@Before
	public void setUp() throws Exception {
		Coffee smallCoffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        Coffee mediumCoffeeWithExtraShot = new Coffee("Medium Coffee", Size.MEDIUM, true, false);
        Coffee largeCoffeeWithExtraSyrup = new Coffee("Large Coffee", Size.LARGE, false, true);
        Coffee mediumCoffeeWithExtraShotAndSyrup = new Coffee("Medium Coffee", Size.MEDIUM, true, true);
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void testCalcPriceSmall() {
		Coffee smallCoffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertEquals(2.0, smallCoffee.calcPrice(), 0.01);
	}
	
	@Test
    public void testCalcPriceMediumWithExtraShot() {
        Coffee mediumCoffeeWithExtraShot = new Coffee("Medium Coffee", Size.MEDIUM, true, false);
        assertEquals(3.0, mediumCoffeeWithExtraShot.calcPrice(), 0.01);
    }

    @Test
    public void testCalcPriceLargeWithExtraSyrup() {
        Coffee largeCoffeeWithExtraSyrup = new Coffee("Large Coffee", Size.LARGE, false, true);
        assertEquals(3.5, largeCoffeeWithExtraSyrup.calcPrice(), 0.01);
    }

    @Test
    public void testCalcPriceMediumWithExtraShotAndSyrup() {
        Coffee mediumCoffeeWithExtraShotAndSyrup = new Coffee("Medium Coffee", Size.MEDIUM, true, true);
        assertEquals(3.5, mediumCoffeeWithExtraShotAndSyrup.calcPrice(), 0.01);
    }

    @Test
    public void testToString() {
		Coffee smallCoffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertEquals("Beverage Name: Small Coffee, Type: COFFEE, Size: SMALL, Extra Shot: No, Extra Syrup: No, Price: $2.0", 
                     smallCoffee.toString());
        Coffee mediumCoffeeWithExtraShot = new Coffee("Medium Coffee", Size.MEDIUM, true, false);
        assertEquals("Beverage Name: Medium Coffee, Type: COFFEE, Size: MEDIUM, Extra Shot: Yes, Extra Syrup: No, Price: $3.0", 
                     mediumCoffeeWithExtraShot.toString());
        Coffee largeCoffeeWithExtraSyrup = new Coffee("Large Coffee", Size.LARGE, false, true);
        assertEquals("Beverage Name: Large Coffee, Type: COFFEE, Size: LARGE, Extra Shot: No, Extra Syrup: Yes, Price: $3.5", 
                     largeCoffeeWithExtraSyrup.toString());
        Coffee mediumCoffeeWithExtraShotAndSyrup = new Coffee("Medium Coffee", Size.MEDIUM, true, true);
        assertEquals("Beverage Name: Medium Coffee, Type: COFFEE, Size: MEDIUM, Extra Shot: Yes, Extra Syrup: Yes, Price: $3.5", 
                     mediumCoffeeWithExtraShotAndSyrup.toString());
    }

    @Test
    public void testEqualsTrue() {
        Coffee coffee1 = new Coffee("Small Coffee", Size.SMALL, false, false);
        Coffee coffee2 = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertTrue(coffee1.equals(coffee2));
    }

    @Test
    public void testEqualsFalseDifferentSize() {
        Coffee coffee1 = new Coffee("Small Coffee", Size.SMALL, false, false);
        Coffee coffee2 = new Coffee("Small Coffee", Size.MEDIUM, false, false);
        assertFalse(coffee1.equals(coffee2));
    }

    @Test
   public  void testEqualsFalseDifferentExtras() {
        Coffee coffee1 = new Coffee("Small Coffee", Size.SMALL, false, false);
        Coffee coffee2 = new Coffee("Small Coffee", Size.SMALL, true, false);
        assertFalse(coffee1.equals(coffee2));
    }

    @Test
    public void testEqualsFalseNull() {
        Coffee coffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertFalse(coffee.equals(null));
    }

    @Test
    public void testEqualsFalseDifferentClass() {
        Coffee coffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        String notACoffee = "I am not a coffee";
        assertFalse(coffee.equals(notACoffee));
    }

    @Test
    public void testHasExtraShot() {
        Coffee mediumCoffeeWithExtraShot = new Coffee("Medium Coffee", Size.MEDIUM, true, false);
		Coffee smallCoffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertTrue(mediumCoffeeWithExtraShot.hasExtraShot());
        assertFalse(smallCoffee.hasExtraShot());
    }

    @Test
    public void testHasExtraSyrup() {
        Coffee largeCoffeeWithExtraSyrup = new Coffee("Large Coffee", Size.LARGE, false, true);
		Coffee smallCoffee = new Coffee("Small Coffee", Size.SMALL, false, false);
        assertTrue(largeCoffeeWithExtraSyrup.hasExtraSyrup());
        assertFalse(smallCoffee.hasExtraSyrup());
    }

    @Test
    public void testSetExtraShot() {
        Coffee mediumCoffeeWithExtraShot = new Coffee("Medium Coffee", Size.MEDIUM, true, false);
        mediumCoffeeWithExtraShot.setExtraShot(false);
        assertFalse(mediumCoffeeWithExtraShot.hasExtraShot());
    }

    @Test
    public void testSetExtraSyrup() {
        Coffee largeCoffeeWithExtraSyrup = new Coffee("Large Coffee", Size.LARGE, false, true);
        largeCoffeeWithExtraSyrup.setExtraSyrup(false);
        assertFalse(largeCoffeeWithExtraSyrup.hasExtraSyrup());
    }
}


