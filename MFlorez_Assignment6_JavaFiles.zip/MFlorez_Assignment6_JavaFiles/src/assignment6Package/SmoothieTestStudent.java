package assignment6Package;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SmoothieTestStudent {
	
//	private Smoothie smoothieWithProtein;
//    private Smoothie smoothieWithExtraFruit;
//    private Smoothie smoothieWithBoth;
//    private Smoothie smoothieWithoutExtras;

	@Before
	public void setUp() throws Exception {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        Smoothie smoothieWithExtraFruit = new Smoothie("Berry Smoothie", Size.LARGE, 3, false); 
        Smoothie smoothieWithBoth = new Smoothie("Tropical Smoothie", Size.SMALL, 2, true);  
        Smoothie smoothieWithoutExtras = new Smoothie("Plain Smoothie", Size.SMALL, 0, false); 
	}
	
	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testCalcPriceWithProtein() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
		double expectedPrice = smoothieWithProtein.addSizePrice() + Smoothie.ADD_PROTEIN_COST;
        assertEquals(expectedPrice, smoothieWithProtein.calcPrice(),0.01);
	}
	
	@Test
    public void testCalcPriceWithExtraFruit() {
        Smoothie smoothieWithExtraFruit = new Smoothie("Berry Smoothie", Size.LARGE, 3, false); 
        double expectedPrice = smoothieWithExtraFruit.addSizePrice() + (Smoothie.EXTRA_FRUIT_COST * 3);
        assertEquals(expectedPrice, smoothieWithExtraFruit.calcPrice(),0.01);
    }

    @Test
    public void testCalcPriceWithBothExtras() {
        Smoothie smoothieWithBoth = new Smoothie("Tropical Smoothie", Size.SMALL, 2, true);  
        assertEquals(4.5, smoothieWithBoth.calcPrice(),0.01);
    }

    @Test
    public void testCalcPriceWithoutExtras() {
        Smoothie smoothieWithoutExtras = new Smoothie("Plain Smoothie", Size.SMALL, 0, false); 
        double expectedPrice = smoothieWithoutExtras.addSizePrice();
        assertEquals(expectedPrice, smoothieWithoutExtras.calcPrice(),0.01);
    }

    @Test
    public void testToStringWithProtein() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        String expectedString = "Beverage Name: Mango Smoothie, Type: SMOOTHIE, Size: MEDIUM, Add Protein: Yes, Extra Fruit: No, Price: $" + smoothieWithProtein.calcPrice();
        assertEquals(expectedString, smoothieWithProtein.toString());
    }

    @Test
    public void testToStringWithExtraFruit() {
        Smoothie smoothieWithExtraFruit = new Smoothie("Berry Smoothie", Size.LARGE, 3, false); 
        String expectedString = "Beverage Name: Berry Smoothie, Type: SMOOTHIE, Size: LARGE, Add Protein: No, Extra Fruit: Yes, Price: $" + smoothieWithExtraFruit.calcPrice();
        assertEquals(expectedString, smoothieWithExtraFruit.toString());
    }

    @Test
    public void testToStringWithBothExtras() {
        Smoothie smoothieWithBoth = new Smoothie("Tropical Smoothie", Size.SMALL, 2, true);  
        String expectedString = "Beverage Name: Tropical Smoothie, Type: SMOOTHIE, Size: SMALL, Add Protein: Yes, Extra Fruit: Yes, Price: $" + smoothieWithBoth.calcPrice();
        assertEquals(expectedString, smoothieWithBoth.toString());
    }

    @Test
    public void testToStringWithoutExtras() {
        Smoothie smoothieWithoutExtras = new Smoothie("Plain Smoothie", Size.SMALL, 0, false); 
        String expectedString = "Beverage Name: Plain Smoothie, Type: SMOOTHIE, Size: SMALL, Add Protein: No, Extra Fruit: No, Price: $" + smoothieWithoutExtras.calcPrice();
        assertEquals(expectedString, smoothieWithoutExtras.toString());
    }

    @Test
    public void testEqualsSameSmoothie() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        Smoothie sameSmoothie = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);
        assertTrue(smoothieWithProtein.equals(sameSmoothie));
    }

    @Test
    public void testEqualsDifferentSmoothie() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        Smoothie smoothieWithExtraFruit = new Smoothie("Berry Smoothie", Size.LARGE, 3, false); 
        assertFalse(smoothieWithProtein.equals(smoothieWithExtraFruit));
    }

    @Test
    public void testEqualsNull() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        assertFalse(smoothieWithProtein.equals(null));
    }

    @Test
    public void testEqualsDifferentClass() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        String someString = "Not a smoothie";
        assertFalse(smoothieWithProtein.equals(someString));
    }

    @Test
    public void testEqualsWithDifferentSize() {
		Smoothie smoothieWithProtein = new Smoothie("Mango Smoothie", Size.MEDIUM, 0, true);  
        Smoothie differentSizeSmoothie = new Smoothie("Mango Smoothie", Size.LARGE, 0, true);
        assertFalse(smoothieWithProtein.equals(differentSizeSmoothie));
    }

}
