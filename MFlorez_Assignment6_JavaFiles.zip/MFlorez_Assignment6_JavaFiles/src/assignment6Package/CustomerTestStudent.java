package assignment6Package;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CustomerTestStudent {
	
//	private Customer customer1;
//    private Customer customer2;
//    private Customer customer3;

	@Before
	public void setUp() throws Exception {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer2 = new Customer("Jane Smith", 25);
        Customer customer3 = new Customer(customer1);  
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCustomerConstructor() {
		Customer customer1 = new Customer("John Doe", 30);  
		assertEquals("John Doe", customer1.getName());
        assertEquals(30, customer1.getAge());
	}
	
	@Test
    public void testCustomerCopyConstructor() {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer3 = new Customer(customer1);  
        assertEquals(customer1.getName(), customer3.getName());
        assertEquals(customer1.getAge(), customer3.getAge());
    }

    @Test
    public void testSetName() {
		Customer customer1 = new Customer("John Doe", 30);  
        customer1.setName("New Name");
        assertEquals("New Name", customer1.getName());
    }

    @Test
    public void testSetAge() {
		Customer customer1 = new Customer("John Doe", 30);  
        customer1.setAge(35);
        assertEquals(35, customer1.getAge());
    }

    @Test
    public void testToString() {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer2 = new Customer("Jane Smith", 25);
        assertEquals("Customer Name: John Doe, Age: 30", customer1.toString());
        assertEquals("Customer Name: Jane Smith, Age: 25", customer2.toString());
    }

    @Test
    public void testEqualsTrue() {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer4 = new Customer("John Doe", 30);
        assertFalse(customer1.equals(customer4));
    }

    @Test
    public void testEqualsFalseDifferentName() {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer2 = new Customer("Jane Smith", 25);
        assertFalse(customer1.equals(customer2));
    }

    @Test
    public void testEqualsFalseDifferentAge() {
		Customer customer1 = new Customer("John Doe", 30);  
        Customer customer5 = new Customer("John Doe", 40);
        assertFalse(customer1.equals(customer5));
    }

    @Test
    public void testEqualsFalseDifferentObject() {
		Customer customer1 = new Customer("John Doe", 30);  
        assertFalse(customer1.equals(null));
    }

    @Test
    public void testEqualsFalseDifferentClass() {
		Customer customer1 = new Customer("John Doe", 30);  
        assertFalse(customer1.equals("Not a customer"));
    }
}


