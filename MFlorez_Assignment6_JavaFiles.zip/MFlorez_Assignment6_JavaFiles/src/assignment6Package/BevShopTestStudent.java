package assignment6Package;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BevShopTestStudent {
	
	 private BevShop bevShop;
	 private Customer customer;

	@Before
	public void setUp() throws Exception {
		bevShop = new BevShop();
	    customer = new Customer("John Doe", 25);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testStartNewOrder() {
		bevShop.startNewOrder(12, Day.MONDAY, customer.getName(), customer.getAge());
        assertNotNull(bevShop.getCurrentOrder());
        assertEquals(customer.getName(), bevShop.getCurrentOrder().getCustomer().getName());
        assertEquals(customer.getAge(), bevShop.getCurrentOrder().getCustomer().getAge());
	}
	
	@Test
    public void testProcessCoffeeOrder() {
        bevShop.startNewOrder(14, Day.TUESDAY, customer.getName(), customer.getAge());
        bevShop.processCoffeeOrder("Espresso", Size.SMALL, false, false);
        assertEquals(1, bevShop.getCurrentOrder().getBeverages().size());
        assertTrue(bevShop.getCurrentOrder().getBeverages().get(0) instanceof Coffee);
    }

    @Test
    public void testProcessAlcoholOrder() {
        bevShop.startNewOrder(10, Day.WEDNESDAY, customer.getName(), customer.getAge());
        bevShop.processAlcoholOrder("Vodka", Size.LARGE);
        assertEquals(1, bevShop.getCurrentOrder().getBeverages().size());
        assertTrue(bevShop.getCurrentOrder().getBeverages().get(0) instanceof Alcohol);
    }

    @Test
    public void testProcessSmoothieOrder() {
        bevShop.startNewOrder(16, Day.THURSDAY, customer.getName(), customer.getAge());
        bevShop.processSmoothieOrder("Mango Smoothie", Size.MEDIUM, 3, true);
        assertEquals(1, bevShop.getCurrentOrder().getBeverages().size());
        assertTrue(bevShop.getCurrentOrder().getBeverages().get(0) instanceof Smoothie);
    }

    @Test
    public void testAddOrder() {
        bevShop.startNewOrder(15, Day.FRIDAY, customer.getName(), customer.getAge());
        bevShop.processCoffeeOrder("Latte", Size.SMALL, false, true);

        assertEquals(1, bevShop.getOrders().size());
    }

    @Test
    public void testAlcoholOrderLimit() {
        bevShop.startNewOrder(20, Day.SATURDAY, customer.getName(), customer.getAge());
        bevShop.processAlcoholOrder("Beer", Size.SMALL);
        bevShop.processAlcoholOrder("Whiskey", Size.MEDIUM);
        bevShop.processAlcoholOrder("Vodka", Size.LARGE);
        
        bevShop.processAlcoholOrder("Tequila", Size.SMALL);
        
        assertEquals(3, bevShop.getCurrentOrder().getBeverages().size());
    }

    @Test
    public void testTotalSalesCalculation() {
        bevShop.startNewOrder(9, Day.SUNDAY, customer.getName(), customer.getAge());
        bevShop.processSmoothieOrder("Berry Smoothie", Size.MEDIUM, 2, false);

        bevShop.startNewOrder(11, Day.MONDAY, customer.getName(), customer.getAge());
        bevShop.processAlcoholOrder("Wine", Size.LARGE);

        assertEquals(6.5, bevShop.getTotalMonthlySale(), 0.01);
    }

    @Test
    public void testIsValidTime() {
        assertTrue(bevShop.isValidTime(15));
        assertFalse(bevShop.isValidTime(24));
    }

    @Test
    public void testFindOrder() {
        bevShop.startNewOrder(18, Day.SUNDAY, customer.getName(), customer.getAge());
        bevShop.processCoffeeOrder("Americano", Size.LARGE, true, false);
        bevShop.addOrder(bevShop.getCurrentOrder());

        int orderIndex = bevShop.findOrder(bevShop.getOrders().get(0).getOrderNumber());
        assertEquals(0, orderIndex);

        assertEquals(-1, bevShop.findOrder(999));
    }

    @Test
    public void testSortOrders() {
    	bevShop.clearOrders();
        bevShop.startNewOrder(18, Day.SUNDAY, customer.getName(), customer.getAge());
        bevShop.processSmoothieOrder("Green Smoothie", Size.LARGE, 5, true);

        bevShop.startNewOrder(10, Day.MONDAY, customer.getName(), customer.getAge());
        bevShop.processAlcoholOrder("Vodka", Size.MEDIUM);

        bevShop.sortOrders();
        
        assertEquals(10, bevShop.getOrders().get(0).getOrderTime());
        assertEquals(18, bevShop.getOrders().get(1).getOrderTime());
    }

}
