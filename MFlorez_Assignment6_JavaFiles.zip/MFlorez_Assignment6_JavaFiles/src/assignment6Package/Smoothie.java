package assignment6Package;

public class Smoothie extends Beverage {
	
	public static final double ADD_PROTEIN_COST = 1.50;
	public static final double EXTRA_FRUIT_COST = 0.50;
	
	private boolean addProtein;
	private int extraFruit;
	
	public Smoothie(String name, Size size, int extraFruit, boolean addProtein) {
		super(name, Type.SMOOTHIE, size);
		this.extraFruit = extraFruit;
		this.addProtein = addProtein;
	}

	@Override
	public String toString() {
		return super.toString() + ", Add Protein: " + (addProtein ? "Yes" : "No")
				+ ", Extra Fruit: " + (extraFruit > 0 ? "Yes" : "No")
				+ ", Price: $" + calcPrice();
	}
	
	@Override
	public double calcPrice() {
		double price = addSizePrice();
		if(addProtein) {
			price += ADD_PROTEIN_COST;
		}
		if(extraFruit > 0) {
			price += EXTRA_FRUIT_COST * extraFruit;
		}
		return price;
	}
	
	@Override
	public boolean equals (Object obj) {
		if(this == obj) return true;
		if(obj == null || getClass() != obj.getClass()) return false;
		if(!super.equals(obj)) return false;
		Smoothie smoothie = (Smoothie) obj;
		return addProtein == smoothie.addProtein && extraFruit == smoothie.extraFruit;
	}

}
