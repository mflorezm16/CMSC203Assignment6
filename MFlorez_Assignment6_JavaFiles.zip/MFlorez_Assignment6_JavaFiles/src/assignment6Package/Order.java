package assignment6Package;

import java.util.ArrayList;
import java.util.List;

public class Order implements OrderInterface, Comparable<Order> {
	
	private int orderNumber;
	private int orderTime;
	private Day orderDay;
	private Customer customer;
	private List<Beverage> beverages;
	
	private static final int MIN_ORDER_NUMBER = 10000;
	private static final int MAX_ORDER_NUMBER = 90000;
	
	public Order(int orderTime, Day orderDay, Customer customer) {
		this.orderNumber = generateRandomOrderNumber();
		this.orderTime = orderTime;
		this.orderDay = orderDay;
		this.customer = new Customer(customer);
		this.beverages = new ArrayList<>();
	}
	
//	public Order(int i, Day sunday, Customer customer2) {
//		this.orderNumber = i;
//		this.orderDay = sunday;
//		this.customer = customer2;
//		this.beverages = new ArrayList<>();
//	}

	public Order() {
		
	}

	private int generateRandomOrderNumber() {
		return (int) (Math.random() * (MAX_ORDER_NUMBER - MIN_ORDER_NUMBER + 1)) + MIN_ORDER_NUMBER;
	}
	
	
	public void addNewBeverage(Beverage beverage) {
		beverages.add(beverage);
	}
	
	
	public void addNewBeverage(Coffee coffee) {
		beverages.add(coffee);
	}
	
	
	public void addNewBeverage(Smoothie smoothie) {
		beverages.add(smoothie);
	}
	
	
	public void addNewBeverage(Alcohol alcohol) {
		beverages.add(alcohol);
	}
	
	public Customer getCustomer() {
		return new Customer(customer);
	}
	
	@Override
	public String toString() {
		StringBuilder orderDetails = new StringBuilder();
		orderDetails.append("Order Number: " + orderNumber)
		.append(", Order Time: " + orderTime)
		.append(", Order Day: " + orderDay)
		.append(", Customer: " + customer.getName() + ", Age: " + customer.getAge())
		.append("\nBeverages:\n");
		
		for(Beverage beverage : beverages) {
			orderDetails.append(beverage.toString() + "\n");
		}
		return orderDetails.toString();
	}
	
	@Override
	public int compareTo(Order otherOrder) {
		if(this.orderNumber == otherOrder.orderNumber) {
			return 0;
		} else if(this.orderNumber > otherOrder.orderNumber) {
			return 1;
		} else {
			return -1;
		}
	}
	
	public int getOrderNumber() {
		return orderNumber;
	}
	
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	
	public int getOrderTime() {
		return orderTime;
	}
	
	public void setOrderTime(int orderTime) {
		this.orderTime = orderTime;
	}
	
	public Day getOrderDay() {
		return orderDay;
	}
	
	public void setOrderDay(Day orderDay) {
		this.orderDay = orderDay;
	}
	
	public List<Beverage> getBeverages(){
		return beverages;
	}
	
	public void setBeverages(List<Beverage> beverages) {
		this.beverages = beverages;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = new Customer(customer);
	}

	@Override
	public boolean isWeekend() {
		/**
		 * 
		 * @return true if the day is a weekend day (Saturday or Sunday)
		 */
		if(orderDay == Day.SATURDAY || orderDay == Day.SUNDAY) {
			return true;
		}
		
		return false;
	}

	@Override
	public Beverage getBeverage(int itemNo) {
		/**
		 * returns the beverage listed in the itemNo of the order, for example if
		 * itemNo is 0 this method will return the first beverage in the order
		 * Note: this method returns the shallow copy of the Beverage
		 * 
		 * @return the beverage listed in the itemNo of the order or null if there
		 *         is no item in the order
		 * 
		 */
		if(this.beverages.size() == 0) {
			return null;
		}
		else {
			return this.beverages.get(itemNo);
		}		
	}

	@Override
	public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
		Coffee coffee = new Coffee(bevName, size, extraShot, extraSyrup);
		beverages.add(coffee);
	}

	@Override
	public void addNewBeverage(String bevName, Size size) {
		Alcohol alcohol = new Alcohol(bevName, size, false); // need to double check proper use of false variable
		beverages.add(alcohol);
	}

	@Override
	public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {
		Smoothie smoothie = new Smoothie(bevName, size, numOfFruits, addProtein);
		beverages.add(smoothie);
	}

	@Override
	public double calcOrderTotal() {
		double result = 0.0;
		for(int i = 0; i < beverages.size(); i++){
			result += beverages.get(i).calcPrice();
		}

		return result;
	}

	@Override
	public int findNumOfBeveType(Type type) {
		int result = 0;
		for(int i = 0; i < beverages.size(); i++){
			if(this.beverages.get(i).getType() == type) {
				result++;
			}
		}
		return result;
	}

	public int getTotalItems() {
		return beverages.size();
	}
	
	public int alcoholCountInOrder() {
		int alcoholCountInOrder = 0;
		for(Beverage beverage : this.beverages) {
			if(beverage.getType() == Type.ALCOHOL) {
				alcoholCountInOrder++;
			}
		}
		return alcoholCountInOrder;
	}

	
}
