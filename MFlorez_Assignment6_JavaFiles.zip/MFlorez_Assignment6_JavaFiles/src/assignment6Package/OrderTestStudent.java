package assignment6Package;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OrderTestStudent {

	
	
	Order orderOne, orderTwo, orderThree, orderFour;

	@Before
	public void setUp() throws Exception {
		orderOne = new Order(2, Day.TUESDAY, new Customer("Mike", 26));
		orderTwo = new Order(14, Day.FRIDAY, new Customer("Jane", 54));
		orderThree = new Order(9, Day.WEDNESDAY, new Customer("Kevin", 22));
	}

	@After
	public void tearDown() throws Exception {
		orderOne = orderTwo = orderThree = null;
	}

	@Test
	public void testGetBeverage() {
		Coffee cf = new Coffee("Plain Coffee", Size.MEDIUM, false, false);
		Alcohol al = new Alcohol("Beer", Size.LARGE, false);
		Smoothie sm1 = new Smoothie("Detox", Size.SMALL, 1, false);
		Smoothie sm2 = new Smoothie("Detox", Size.MEDIUM, 1, false);

		orderOne.addNewBeverage("Plain Coffee", Size.SMALL, false, false);
		orderOne.addNewBeverage("Beer", Size.LARGE, false, false);
		orderOne.addNewBeverage("Detox", Size.MEDIUM, 1, false);
		assertFalse(orderOne.getBeverage(0).equals(cf));
		assertFalse(orderOne.getBeverage(1).equals(al));
		assertFalse(orderOne.getBeverage(2).equals(sm1));
		assertTrue(orderOne.getBeverage(2).equals(sm2));
	}

	@Test
	public void testAddNewBeverage() throws NullPointerException {
		Order orderFour = new Order(2, Day.TUESDAY, new Customer("Mike", 26));
		assertTrue(orderFour.getTotalItems() == 0);
		orderFour.addNewBeverage("Plain Coffee", Size.MEDIUM, false, false);
		assertTrue(orderFour.getBeverage(0).getType().equals(Type.COFFEE));
		orderFour.addNewBeverage("Mohito", Size.MEDIUM);
		assertTrue(orderFour.getBeverage(1).getType().equals(Type.ALCOHOL));
		orderFour.addNewBeverage("Detox", Size.LARGE, 1, false);
		assertTrue(orderFour.getBeverage(2).getType().equals(Type.SMOOTHIE));
		assertTrue(orderFour.getTotalItems() == 3);
		
		Order orderFive = new Order(14, Day.FRIDAY, new Customer("Jane", 54));
		orderFive.addNewBeverage("Detox", Size.MEDIUM, 4, true);
		assertTrue(orderFive.getBeverage(0).getType().equals(Type.SMOOTHIE));
		orderFive.addNewBeverage("Mohito", Size.SMALL);
		assertTrue(orderFive.getBeverage(1).getType().equals(Type.ALCOHOL));
		orderFive.addNewBeverage("regular Coffee", Size.MEDIUM, true, false);
		assertTrue(orderFive.getBeverage(2).getType().equals(Type.COFFEE));
		assertTrue(orderFive.getTotalItems() == 3);
	}

	@Test
	public void testCalcOrderTotal() {
		Order orderFour = new Order(8, Day.MONDAY, new Customer("Mary", 22));
		orderFour.addNewBeverage("regular Coffee", Size.SMALL, false, false);
		orderFour.addNewBeverage("Mohito", Size.LARGE);
		orderFour.addNewBeverage("Detox", Size.SMALL, 1, false);

		assertEquals(7.5, orderFour.calcOrderTotal(), .01);
		
		Order orderFive = new Order(12, Day.SATURDAY, new Customer("John", 45));
		orderFive.addNewBeverage("regular Coffee", Size.LARGE, true, false);
		orderFive.addNewBeverage("Mohito", Size.MEDIUM);
		orderFive.addNewBeverage("Detox", Size.LARGE, 4, true);

		assertEquals(12.5, orderFive.calcOrderTotal(), .01);
		
	}	

}
