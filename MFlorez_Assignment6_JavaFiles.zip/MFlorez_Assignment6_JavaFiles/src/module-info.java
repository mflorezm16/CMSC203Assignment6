/**
 * 
 */
/**
 * 
 */
module CMSC203_Assignment6 {
	// requires org.junit.jupiter.api;
	requires java.desktop;
	requires junit;
}